import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  User? getCurrentUser() {
    return _auth.currentUser;
  }

  //register
  Future<UserCredential> register(String email, String password,
      [String? username]) async {
    try {
      UserCredential userCredential = await _auth
          .createUserWithEmailAndPassword(email: email, password: password);
      // _firestore.collection("Users").doc(userCredential.user!.uid).set({
      //   "uid": userCredential.user!.uid,
      //   "email": email,
      // });

      await _firestore.collection("Users").doc(userCredential.user!.uid).set({
        "uid": userCredential.user!.uid,
        "email": email,
        // if (username != null) "username": username,
        "status": "online", // Set the user as online when they register
        "last_active":
            FieldValue.serverTimestamp(), // Record the last active timestamp
      });
      setUserPresence(userCredential.user!.uid);

      return userCredential;
    } on FirebaseAuthException catch (e) {
      throw Exception(e.code);
    }
  }

  Future<UserCredential> login(String email, String password) async {
    try {
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      await _firestore.collection("Users").doc(userCredential.user!.uid).set({
        "uid": userCredential.user!.uid,
        "email": email,
        // if (username != null) "username": username,
        "status": "online", // Set the user as online when they register
        "last_active":
            FieldValue.serverTimestamp(), // Record the last active timestamp
      });
      setUserPresence(userCredential.user!.uid);

      return userCredential;
    } on FirebaseAuthException catch (e) {
      throw Exception(e.code);
    }
  }

  Future<void> signOut() async {
    final userId = _auth.currentUser?.uid;
    await _firestore.collection("Users").doc(userId).update({
      "status": "offline",
      "last_active": FieldValue.serverTimestamp(),
    });

    return await _auth.signOut();
  }

  void setUserPresence(String userId) {
    final userStatusRef = _firestore.collection("Users").doc(userId);

    // Mark the user as online
    userStatusRef.update({
      "status": "online",
      "last_active": FieldValue.serverTimestamp(),
    });

    // Set up the disconnection handler to mark the user as offline when they go offline
    _auth.authStateChanges().listen((User? user) {
      if (user == null) {
        // User signed out, mark as offline
        userStatusRef.update({
          "status": "offline",
          "last_active": FieldValue.serverTimestamp(),
        });
      }
    });
  }
}
