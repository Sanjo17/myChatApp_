import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:mychatapp/services/auth/auth_service.dart';

class UserStatusServices {
  final AuthService _auth = AuthService();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  void updateUserStatus(String status) async {
    User? user = _auth.getCurrentUser();
    if (user != null) {
      await _firestore.collection('Users').doc(user.uid).update({
        'status': status,
        'last_active': FieldValue.serverTimestamp()
      });
    }
  }
}
