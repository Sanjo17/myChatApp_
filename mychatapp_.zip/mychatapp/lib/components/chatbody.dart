import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class ChatBody extends StatelessWidget {
  DateTime convertTimestamp(int milliseconds, int nanoseconds) {
    // Convert milliseconds and nanoseconds to microseconds
    int microseconds = milliseconds * 1000 + nanoseconds ~/ 1000;

    // Create DateTime from microseconds
    DateTime dateTime = DateTime.fromMicrosecondsSinceEpoch(microseconds);

    return dateTime;
  }

  String formatTimeOnly(DateTime dateTime) {
    // Format the DateTime object to only show time in AM/PM format
    return DateFormat('h:mm a').format(dateTime);
  }

  final String message;
  final Timestamp time;
  final bool isCurrentUser;
  const ChatBody(
      {super.key,
      required this.message,
      required this.isCurrentUser,
      required this.time});

  @override
  Widget build(BuildContext context) {
    // DateTime dateTime = convertTimestamp(time.seconds, time.nanoseconds);
    // String formattedTime = formatTimeOnly(dateTime);

    return Container(
      padding: const EdgeInsets.all(8),
      margin: const EdgeInsets.symmetric(horizontal: 25, vertical: 5),
      decoration: BoxDecoration(
          color: isCurrentUser ? Colors.green : Colors.grey.shade500,
          borderRadius: BorderRadius.circular(6)),
      child: Column(
        children: [
          Text(
            message,
            style: const TextStyle(color: Colors.white, fontSize: 20),
          ),
          // Text(formattedTime, style: const TextStyle(fontSize: 15))
        ],
      ),
    );
  }
}
