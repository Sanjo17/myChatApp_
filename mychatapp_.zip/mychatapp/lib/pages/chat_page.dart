import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:emoji_picker_flutter/emoji_picker_flutter.dart';
import 'package:flutter/material.dart';
import 'package:mychatapp/components/chatbody.dart';
import 'package:mychatapp/components/inputfield.dart';
import 'package:mychatapp/services/auth/auth_service.dart';
import 'package:mychatapp/services/chat/chat_services.dart';

class ChatPage extends StatefulWidget {
  final String receiverEmail;
  final String receiverId;
  const ChatPage(
      {super.key, required this.receiverEmail, required this.receiverId});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final TextEditingController _messageController = TextEditingController();

  final ChatServices _chatService = ChatServices();

  final AuthService _authService = AuthService();

  bool _showEmojiPicker = false;

  void sendMessage() async {
    if (_messageController.text.isNotEmpty) {
      await _chatService.sendMessage(
          widget.receiverId, _messageController.text);
      _messageController.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    double screenHeight = MediaQuery.of(context).size.height;

    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        appBar: AppBar(
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(widget.receiverEmail),
              _buildOnlineStatus(),
            ],
          ),
        ),
        body: Column(
          children: [
            Expanded(child: _buildMessageList()),
            _buildUserInput(),
            if (_showEmojiPicker)
              SizedBox(
                height: screenHeight * .35,
                child: EmojiPicker(
                  textEditingController: _messageController,
                  config: Config(
                    height: screenHeight * .35,
                    checkPlatformCompatibility: true,
                  ),
                ),
              )
          ],
        ),
      ),
    );
  }

  Widget _buildMessageList() {
    String senderId = _authService.getCurrentUser()!.uid;
    return StreamBuilder(
        stream: _chatService.getMessages(widget.receiverId, senderId),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return const Text("Error");
          }
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Text("Loading");
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text("No messages yet."));
          }
          return ListView(
            children: snapshot.data!.docs
                .map((doc) => _buildMessageItem(doc))
                .toList(),
          );
        });
  }

  Widget _buildMessageItem(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;

    bool isCurrentUser = data["senderId"] == _authService.getCurrentUser()!.uid;

    var alignment =
        isCurrentUser ? Alignment.centerRight : Alignment.centerLeft;

    return Container(
      alignment: alignment,
      child: Column(
        crossAxisAlignment:
            isCurrentUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          ChatBody(
            message: data['message'],
            isCurrentUser: isCurrentUser,
            time: data['timestamp'],
          ),
        ],
      ),
    );
  }

  Widget _buildUserInput() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 15, left: 5),
      child: Row(
        children: [
          Expanded(
              child: Card(
            color: Theme.of(context).colorScheme.secondary,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            child: Row(
              children: [
                IconButton(
                  padding: const EdgeInsets.symmetric(horizontal: 1),
                  icon: const Icon(Icons.emoji_emotions),
                  onPressed: () {
                    setState(() {
                      _showEmojiPicker = !_showEmojiPicker;
                      FocusScope.of(context).unfocus();
                    });
                  },
                ),
                Expanded(
                  child: MyInputField(
                      onTap: () {
                        if (_showEmojiPicker) {
                          setState(() {
                            _showEmojiPicker = !_showEmojiPicker;
                          });
                        }
                      },
                      horizontalP: 0,
                      controller: _messageController,
                      hintText: "Type any message",
                      obscureText: false),
                ),
                IconButton(
                    onPressed: sendMessage, icon: const Icon(Icons.send)),
              ],
            ),
          )),
        ],
      ),
    );
  }

  Widget _buildOnlineStatus() {
    return StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance
          .collection('Users')
          .doc(widget.receiverId)
          .snapshots(), // Listening to the status changes
      builder: (context, snapshot) {
        if (!snapshot.hasData || snapshot.data == null) {
          return Container(); // Return an empty container if no data
        }

        var userData = snapshot.data!.data() as Map<String, dynamic>?;
        String status = userData?['status'] ?? 'offline'; // Default to offline

        return Row(
          children: [
            Icon(
              status == 'online' ? Icons.circle : Icons.circle_outlined,
              color: status == 'online' ? Colors.green : Colors.grey,
              size: 12,
            ),
            const SizedBox(width: 4),
            Text(
              status == 'online' ? "Online" : "Offline",
              style: TextStyle(
                color: status == 'online' ? Colors.green : Colors.grey,
                fontSize: 12,
              ),
            ),
          ],
        );
      },
    );
  }
}
