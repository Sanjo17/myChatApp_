import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:mychatapp/components/usertile.dart';
import 'package:mychatapp/pages/chat_page.dart';
import 'package:mychatapp/services/auth/auth_service.dart';
import 'package:mychatapp/services/chat/chat_services.dart';
import 'package:mychatapp/services/user/userstatus_services.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver   {
  final UserStatusServices _userStatusService = UserStatusServices();
  final ChatServices _chatService = ChatServices();

  final AuthService _authService = AuthService();
 @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _updateStatus('online'); // Update to online when the app is in the foreground
  }
  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _updateStatus('offline'); // Update to offline when the app is disposed
    super.dispose();
    }

    @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _updateStatus('online');
    } else if (state == AppLifecycleState.paused) {
      _updateStatus('offline');
    }
  }
  void _updateStatus(String status) {
    _userStatusService.updateUserStatus(status);
  }



  void logout() {
    _authService.signOut();
  }

  @override
  Widget build(BuildContext context) {
    late User? currentUser = _authService.getCurrentUser();

    return Scaffold(
      appBar: AppBar(
        title: Text(currentUser!.email.toString()),
        actions: [
          IconButton(onPressed: logout, icon: const Icon(Icons.logout))
        ],
      ),
      body: _buildUserList(),
    );
  }

  Widget _buildUserList() {
    return StreamBuilder(
        stream: _chatService.getUsersStream(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return const Text("Error");
          }
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Text("Loading");
          }
          return ListView(
            children: snapshot.data!
                .map<Widget>(
                    (userData) => _buildUserListItem(userData, context))
                .toList(),
          );
        });
  }

  Widget _buildUserListItem(
      Map<String, dynamic> userData, BuildContext context) {
    if (userData["email"] != _authService.getCurrentUser()!.email) {
      return UserTile(
        text: userData["email"],
        onTap: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => ChatPage(
                        receiverEmail: userData["email"],
                        receiverId: userData["uid"],
                      )));
        },
      );
    } else {
      return Container();
    }
  }
}
