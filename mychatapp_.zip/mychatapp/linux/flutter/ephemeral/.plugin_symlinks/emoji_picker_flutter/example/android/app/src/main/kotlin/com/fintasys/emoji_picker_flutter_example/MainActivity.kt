package com.fintasys.emoji_picker_flutter_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
